import UIKit
import AVFoundation

// CarVievo CarPlay TEST uygulaması — sadece deneme içindir.
// Amaç: ESign ile imzalanınca araç ekranında (CarPlay) görünüyor mu?
// Görünüyorsa: dokunma, sürükleme, video ve web sayfası çalışıyor mu?

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Videonun sesi araç hoparlöründen gelsin
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback, options: [])
        TestLog.shared.add("Uygulama açıldı")
        return true
    }
}
