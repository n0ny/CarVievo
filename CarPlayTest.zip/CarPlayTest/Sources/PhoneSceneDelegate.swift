import UIKit

@objc(PhoneSceneDelegate)
final class PhoneSceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    func scene(_ scene: UIScene,
               willConnectTo session: UISceneSession,
               options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }
        let window = UIWindow(windowScene: windowScene)
        window.rootViewController = PhoneViewController()
        window.makeKeyAndVisible()
        self.window = window
    }
}

/// Telefon ekranı: test raporu + "Raporu kopyala" düğmesi
final class PhoneViewController: UIViewController {
    private let textView = UITextView()
    private let copyButton = UIButton(type: .system)
    private let clearButton = UIButton(type: .system)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.06, green: 0.08, blue: 0.13, alpha: 1)

        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.isEditable = false
        textView.backgroundColor = .clear
        textView.textColor = .white
        textView.font = UIFont.monospacedSystemFont(ofSize: 13, weight: .regular)

        copyButton.translatesAutoresizingMaskIntoConstraints = false
        copyButton.setTitle("Raporu kopyala", for: .normal)
        copyButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        copyButton.setTitleColor(.white, for: .normal)
        copyButton.backgroundColor = UIColor(red: 0.13, green: 0.77, blue: 0.55, alpha: 1)
        copyButton.layer.cornerRadius = 12
        copyButton.addTarget(self, action: #selector(copyReport), for: .touchUpInside)

        clearButton.translatesAutoresizingMaskIntoConstraints = false
        clearButton.setTitle("Günlüğü sil", for: .normal)
        clearButton.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        clearButton.setTitleColor(UIColor(white: 0.7, alpha: 1), for: .normal)
        clearButton.addTarget(self, action: #selector(clearLog), for: .touchUpInside)

        view.addSubview(textView)
        view.addSubview(copyButton)
        view.addSubview(clearButton)

        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: g.topAnchor, constant: 8),
            textView.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 12),
            textView.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
            textView.bottomAnchor.constraint(equalTo: copyButton.topAnchor, constant: -8),

            copyButton.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 16),
            copyButton.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -16),
            copyButton.heightAnchor.constraint(equalToConstant: 52),
            copyButton.bottomAnchor.constraint(equalTo: clearButton.topAnchor, constant: -4),

            clearButton.centerXAnchor.constraint(equalTo: g.centerXAnchor),
            clearButton.heightAnchor.constraint(equalToConstant: 36),
            clearButton.bottomAnchor.constraint(equalTo: g.bottomAnchor, constant: -6)
        ])

        NotificationCenter.default.addObserver(self, selector: #selector(refresh),
                                               name: TestLog.changed, object: nil)
        refresh()
    }

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    @objc private func refresh() {
        textView.text = Diagnostics.report()
    }

    @objc private func copyReport() {
        UIPasteboard.general.string = Diagnostics.report()
        copyButton.setTitle("Kopyalandı ✓", for: .normal)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak self] in
            self?.copyButton.setTitle("Raporu kopyala", for: .normal)
        }
    }

    @objc private func clearLog() {
        TestLog.shared.clear()
    }
}
