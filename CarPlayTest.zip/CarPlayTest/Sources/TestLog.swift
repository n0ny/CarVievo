import Foundation

/// Telefonda ve arabada olan her şeyi sırayla kaydeder (uygulama kapansa da silinmez).
final class TestLog {
    static let shared = TestLog()
    static let changed = Notification.Name("CarVievoTestLogChanged")

    private let key = "cv_test_log"
    private(set) var lines: [String]
    private let formatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "dd.MM HH:mm:ss"
        return f
    }()

    private init() {
        lines = UserDefaults.standard.stringArray(forKey: key) ?? []
    }

    func add(_ text: String) {
        let work = {
            self.lines.append("\(self.formatter.string(from: Date()))  \(text)")
            if self.lines.count > 200 {
                self.lines.removeFirst(self.lines.count - 200)
            }
            UserDefaults.standard.set(self.lines, forKey: self.key)
            NotificationCenter.default.post(name: TestLog.changed, object: nil)
        }
        if Thread.isMainThread {
            work()
        } else {
            DispatchQueue.main.async(execute: work)
        }
    }

    func clear() {
        lines = []
        UserDefaults.standard.set(lines, forKey: key)
        NotificationCenter.default.post(name: TestLog.changed, object: nil)
    }
}
