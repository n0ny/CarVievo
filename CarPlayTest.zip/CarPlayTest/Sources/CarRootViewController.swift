import UIKit
import AVFoundation
import WebKit

/// Araç ekranında görünen test sayfası.
/// - Ortada "Merhaba CarVievo" + saniye saniye ilerleyen saat (ekran canlı mı?)
/// - Dokununca sayaç artar (dokunma bize geliyor mu?)
/// - "Video" düğmesi: deneme yayını oynatır (görüntü + ses geliyor mu?)
/// - "Web" düğmesi: m.youtube.com açar (web sayfası çiziliyor mu, beyaz mı kalıyor?)
final class CarRootViewController: UIViewController {
    private static let videoURL = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
    private static let webURL = "https://m.youtube.com"

    private let centerStack = UIStackView()
    private let titleLabel = UILabel()
    private let clockLabel = UILabel()
    private let hintLabel = UILabel()
    private let statusLabel = UILabel()

    private var timer: Timer?
    private var tapCount = 0
    private var lastEvent = "Ekrana dokun: sayaç artmalı"

    private var player: AVPlayer?
    private var playerLayer: AVPlayerLayer?
    private var statusObservation: NSKeyValueObservation?
    private var webView: WKWebView?

    private let timeFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "HH:mm:ss"
        return f
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.05, green: 0.42, blue: 0.32, alpha: 1)

        titleLabel.text = "Merhaba CarVievo"
        titleLabel.font = UIFont.boldSystemFont(ofSize: 34)
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center

        clockLabel.font = UIFont.monospacedDigitSystemFont(ofSize: 28, weight: .semibold)
        clockLabel.textColor = UIColor(white: 1, alpha: 0.9)
        clockLabel.textAlignment = .center

        hintLabel.text = "Üstte: Video · Web düğmeleri"
        hintLabel.font = UIFont.systemFont(ofSize: 16)
        hintLabel.textColor = UIColor(white: 1, alpha: 0.75)
        hintLabel.textAlignment = .center

        centerStack.axis = .vertical
        centerStack.spacing = 10
        centerStack.alignment = .center
        centerStack.translatesAutoresizingMaskIntoConstraints = false
        centerStack.addArrangedSubview(titleLabel)
        centerStack.addArrangedSubview(clockLabel)
        centerStack.addArrangedSubview(hintLabel)
        view.addSubview(centerStack)

        statusLabel.font = UIFont.boldSystemFont(ofSize: 15)
        statusLabel.textColor = .white
        statusLabel.backgroundColor = UIColor(white: 0, alpha: 0.55)
        statusLabel.textAlignment = .center
        statusLabel.numberOfLines = 2
        statusLabel.layer.cornerRadius = 8
        statusLabel.clipsToBounds = true
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(statusLabel)

        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            centerStack.centerXAnchor.constraint(equalTo: g.centerXAnchor),
            centerStack.centerYAnchor.constraint(equalTo: g.centerYAnchor),
            centerStack.leadingAnchor.constraint(greaterThanOrEqualTo: g.leadingAnchor, constant: 12),
            centerStack.trailingAnchor.constraint(lessThanOrEqualTo: g.trailingAnchor, constant: -12),

            statusLabel.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 12),
            statusLabel.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
            statusLabel.bottomAnchor.constraint(equalTo: g.bottomAnchor, constant: -10),
            statusLabel.heightAnchor.constraint(greaterThanOrEqualToConstant: 34)
        ])

        let tap = UITapGestureRecognizer(target: self, action: #selector(tapped(_:)))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)

        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            self?.tick()
        }
        tick()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        playerLayer?.frame = view.bounds
    }

    private func tick() {
        clockLabel.text = timeFormatter.string(from: Date())
        updateStatus()
    }

    private func updateStatus() {
        statusLabel.text = "  Dokunma: \(tapCount)  ·  \(lastEvent)  "
    }

    @objc private func tapped(_ gesture: UITapGestureRecognizer) {
        tapCount += 1
        let p = gesture.location(in: view)
        noteEvent("Dokunma #\(tapCount) (\(Int(p.x)),\(Int(p.y))) ✓")
    }

    func noteEvent(_ text: String) {
        lastEvent = text
        TestLog.shared.add("ARAÇ: " + text)
        updateStatus()
    }

    // MARK: - Video

    func toggleVideo() {
        if player != nil {
            stopVideo()
            noteEvent("Video durduruldu")
            return
        }
        stopWeb()
        guard let url = URL(string: Self.videoURL) else { return }
        try? AVAudioSession.sharedInstance().setActive(true)

        let newPlayer = AVPlayer(url: url)
        let layer = AVPlayerLayer(player: newPlayer)
        layer.videoGravity = .resizeAspect
        layer.backgroundColor = UIColor.black.cgColor
        layer.frame = view.bounds
        view.layer.insertSublayer(layer, at: 0)

        statusObservation = newPlayer.currentItem?.observe(\.status, options: [.new]) { [weak self] item, _ in
            DispatchQueue.main.async {
                switch item.status {
                case .readyToPlay:
                    self?.noteEvent("Video oynuyor ✓")
                case .failed:
                    self?.noteEvent("Video HATA: \(item.error?.localizedDescription ?? "bilinmiyor")")
                default:
                    break
                }
            }
        }

        player = newPlayer
        playerLayer = layer
        centerStack.isHidden = true
        newPlayer.play()
        noteEvent("Video başlatılıyor…")
    }

    private func stopVideo() {
        statusObservation?.invalidate()
        statusObservation = nil
        player?.pause()
        playerLayer?.removeFromSuperlayer()
        player = nil
        playerLayer = nil
        centerStack.isHidden = (webView != nil)
    }

    // MARK: - Web

    func toggleWeb() {
        if webView != nil {
            stopWeb()
            noteEvent("Web kapatıldı")
            return
        }
        stopVideo()
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        let web = WKWebView(frame: view.bounds, configuration: config)
        web.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        web.navigationDelegate = self
        view.insertSubview(web, belowSubview: statusLabel)
        webView = web
        centerStack.isHidden = true
        if let url = URL(string: Self.webURL) {
            web.load(URLRequest(url: url))
        }
        noteEvent("Web açılıyor…")
    }

    private func stopWeb() {
        webView?.stopLoading()
        webView?.removeFromSuperview()
        webView = nil
        centerStack.isHidden = (player != nil)
    }

    func stopAll() {
        timer?.invalidate()
        timer = nil
        stopVideo()
        stopWeb()
    }
}

extension CarRootViewController: WKNavigationDelegate {
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        noteEvent("Web sayfası yüklendi ✓")
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        noteEvent("Web HATA: \(error.localizedDescription)")
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        noteEvent("Web HATA: \(error.localizedDescription)")
    }
}
