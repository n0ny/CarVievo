import UIKit

/// İmza profilini (embedded.mobileprovision) okur: içinde CarPlay izni var mı?
enum Diagnostics {

    static func profile() -> [String: Any]? {
        guard let url = Bundle.main.url(forResource: "embedded", withExtension: "mobileprovision"),
              let data = try? Data(contentsOf: url),
              let text = String(data: data, encoding: .isoLatin1),
              let start = text.range(of: "<?xml"),
              let end = text.range(of: "</plist>", range: start.lowerBound..<text.endIndex)
        else { return nil }
        let plistText = String(text[start.lowerBound..<end.upperBound])
        guard let plistData = plistText.data(using: .isoLatin1) else { return nil }
        let object = try? PropertyListSerialization.propertyList(from: plistData, options: [], format: nil)
        return object as? [String: Any]
    }

    static func report() -> String {
        var r: [String] = []
        let info = Bundle.main.infoDictionary ?? [:]
        let version = info["CFBundleShortVersionString"] as? String ?? "?"
        r.append("CARVIEVO CARPLAY TESTİ  v\(version)")
        r.append("Paket: \(Bundle.main.bundleIdentifier ?? "?")")
        r.append("iOS: \(UIDevice.current.systemVersion)")
        r.append("")
        r.append("— İMZA PROFİLİ —")

        if let p = profile() {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd.MM.yyyy"
            r.append("Profil: \(p["Name"] as? String ?? "?")")
            r.append("Ekip: \(p["TeamName"] as? String ?? "?")")
            if let exp = p["ExpirationDate"] as? Date {
                r.append("Bitiş: \(dateFormatter.string(from: exp))")
            }
            if (p["ProvisionsAllDevices"] as? Bool) == true {
                r.append("Tür: Kurumsal (enterprise) sertifika")
            }
            let ents = p["Entitlements"] as? [String: Any] ?? [:]
            let carplay = ents.keys.filter { $0.contains("carplay") }.sorted()
            if carplay.isEmpty {
                r.append("CarPlay izni: YOK ✗")
                r.append("SONUÇ: Arabada büyük ihtimalle GÖRÜNMEZ.")
            } else {
                r.append("CarPlay izni: VAR ✓")
                for key in carplay {
                    r.append("  • \(key)")
                }
                if carplay.contains("com.apple.developer.carplay-maps") {
                    r.append("SONUÇ: Navigasyon izni var, arabada görünmeli.")
                } else {
                    r.append("SONUÇ: CarPlay izni var ama navigasyon izni değil.")
                }
            }
            r.append("Profildeki izin sayısı: \(ents.count)")
        } else {
            r.append("İmza profili bulunamadı.")
            r.append("(İmzasız kurulum ya da profilsiz imza.)")
        }

        r.append("")
        r.append("— ARAÇ EKRANI —")
        r.append("CarPlay şu an: \(CarPlaySceneDelegate.isConnected ? "BAĞLI ✓" : "bağlı değil")")
        r.append("")
        r.append("— GÜNLÜK (en yeni üstte) —")
        let lines = TestLog.shared.lines
        if lines.isEmpty {
            r.append("(boş)")
        } else {
            r.append(contentsOf: lines.reversed())
        }
        return r.joined(separator: "\n")
    }
}
