import UIKit
import CarPlay

/// Araç ekranı (CarPlay) bağlanınca çalışır.
/// Navigasyon uygulaması gibi kaydolur: Apple bize serbest bir "harita" yüzeyi verir,
/// biz o yüzeye kendi ekranımızı (CarRootViewController) çizeriz.
@objc(CarPlaySceneDelegate)
final class CarPlaySceneDelegate: UIResponder, CPTemplateApplicationSceneDelegate {
    static var isConnected = false

    private var interfaceController: CPInterfaceController?
    private var carWindow: CPWindow?
    private var carVC: CarRootViewController?

    func templateApplicationScene(_ templateApplicationScene: CPTemplateApplicationScene,
                                  didConnect interfaceController: CPInterfaceController,
                                  to window: CPWindow) {
        CarPlaySceneDelegate.isConnected = true
        let w = Int(window.bounds.width)
        let h = Int(window.bounds.height)
        TestLog.shared.add("ARAÇ: CarPlay bağlandı ✓ (ekran \(w)x\(h))")

        self.interfaceController = interfaceController
        self.carWindow = window

        let vc = CarRootViewController()
        window.rootViewController = vc
        carVC = vc

        let mapTemplate = CPMapTemplate()
        mapTemplate.mapDelegate = self
        mapTemplate.automaticallyHidesNavigationBar = false

        let videoButton = CPBarButton(title: "Video") { [weak self] _ in
            self?.carVC?.toggleVideo()
        }
        let webButton = CPBarButton(title: "Web") { [weak self] _ in
            self?.carVC?.toggleWeb()
        }
        mapTemplate.leadingNavigationBarButtons = [videoButton]
        mapTemplate.trailingNavigationBarButtons = [webButton]

        interfaceController.setRootTemplate(mapTemplate, animated: false, completion: nil)
    }

    func templateApplicationScene(_ templateApplicationScene: CPTemplateApplicationScene,
                                  didDisconnect interfaceController: CPInterfaceController,
                                  from window: CPWindow) {
        CarPlaySceneDelegate.isConnected = false
        carVC?.stopAll()
        carVC = nil
        carWindow = nil
        self.interfaceController = nil
        TestLog.shared.add("ARAÇ: CarPlay bağlantısı kesildi")
    }
}

// Araç ekranında parmakla sürükleme gelirse günlüğe yazar
extension CarPlaySceneDelegate: CPMapTemplateDelegate {
    func mapTemplateDidBeginPanGesture(_ mapTemplate: CPMapTemplate) {
        carVC?.noteEvent("Sürükleme başladı ✓")
    }

    func mapTemplate(_ mapTemplate: CPMapTemplate, didEndPanGestureWithVelocity velocity: CGPoint) {
        carVC?.noteEvent("Sürükleme bitti")
    }
}
